(() => {
'use strict';
const canvas=document.getElementById('game'),ctx=canvas.getContext('2d');
ctx.imageSmoothingEnabled=false;
const W=960,H=540;
const ui={inventory:document.getElementById('inventory'),log:document.getElementById('log'),toast:document.getElementById('toast'),hint:document.getElementById('interaction-hint')};
const state={
 scene:'house',time:0,day:1,minute:380,water:0.04,paused:false,
 player:{x:155,y:390,vx:0,vy:0,onGround:true,face:1,health:100,hunger:12,thirst:18,temp:36.4,stamina:100},
 inventory:[
  {id:'water',name:'Agua limpia',glyph:'▣',count:1,weight:0.8,type:'drink'},
  {id:'food',name:'Conserva',glyph:'◉',count:2,weight:0.5,type:'food'},
  {id:'bandage',name:'Vendas',glyph:'✚',count:2,weight:0.2,type:'heal'},
  {id:'flashlight',name:'Linterna',glyph:'▰',count:1,weight:0.4,type:'tool'},
  {id:'knife',name:'Cuchillo',glyph:'†',count:1,weight:0.3,type:'tool'},
  {id:'wood',name:'Madera',glyph:'▤',count:2,weight:1.2,type:'material'},
  {id:'jacket',name:'Abrigo',glyph:'♧',count:1,weight:0.8,type:'clothing'}
 ],
 selected:0,items:[],objects:[],logs:[],flags:{tv:false,firstSupplies:false,highGround:false,storeSearched:false,refugeBuilt:false,survivorMet:false,streetCache:false,clinicNote:false,clinicLoot:false,apartmentLoot:false,radioFixed:false,waterworksLoot:false,valveClosed:false,filterCrafted:false,sideRescue:false},unlocked:['house','street','roof'],near:null,weather:'LLUVIA INTENSA',autosave:0
};
const scenes={
 house:{name:'CASA · PLANTA BAJA',ground:436,waterLine:475,sky:'#202d35',objective:'OBJETIVO: reúne suministros y alcanza terreno elevado',width:1700},
 street:{name:'BARRIO RESIDENCIAL',ground:425,waterLine:450,sky:'#1b2c35',objective:'OBJETIVO: encuentra una ruta hacia el refugio elevado',width:1900},
 roof:{name:'REFUGIO · AZOTEA',ground:360,waterLine:420,sky:'#263a43',objective:'OBJETIVO: examina el refugio y planifica la exploración',width:1200},
 store:{name:'MINIMERCADO INUNDADO',ground:430,waterLine:455,sky:'#1b272d',objective:'OBJETIVO: busca recursos sin quedarte atrapado',width:1200},
 clinic:{name:'CLÍNICA DE BARRIO',ground:430,waterLine:455,sky:'#263139',objective:'OBJETIVO: registra la clínica y recupera material médico',width:1350},
 apartment:{name:'EDIFICIO RESIDENCIAL',ground:410,waterLine:450,sky:'#242f36',objective:'OBJETIVO: busca suministros y una radio funcional',width:1450},
 waterworks:{name:'ESTACIÓN DE BOMBEO',ground:425,waterLine:450,sky:'#18282f',objective:'OBJETIVO: corta la alimentación y busca una ruta segura',width:1550}
};
function addLog(t){state.logs.unshift(t);state.logs=state.logs.slice(0,12);renderLog();}
function toast(t){ui.toast.textContent=t;ui.toast.classList.add('show');setTimeout(()=>ui.toast.classList.remove('show'),2300);}
function weight(){return state.inventory.reduce((s,i)=>s+i.weight*i.count,0);}
function item(id){return state.inventory.find(i=>i.id===id);}
function addItem(id,name,glyph,count,weight,type){let it=item(id);if(it)it.count+=count;else state.inventory.push({id,name,glyph,count,weight,type});renderInventory();}
function consume(id,n=1){let it=item(id);if(!it||it.count<n)return false;it.count-=n;if(it.count<=0)state.inventory=state.inventory.filter(i=>i.id!==id);state.selected=Math.max(0,Math.min(state.selected,state.inventory.length-1));renderInventory();return true;}
function renderInventory(){ui.inventory.innerHTML='';state.inventory.forEach((it,i)=>{const el=document.createElement('div');el.className='item'+(i===state.selected?' selected':'');el.innerHTML=`<span class="count">${it.count}</span><span class="glyph">${it.glyph}</span><span class="iname">${it.name}</span>`;el.title=`${it.name} · ${(it.weight*it.count).toFixed(1)} kg`;el.onclick=()=>{state.selected=i;renderInventory()};ui.inventory.appendChild(el)});document.getElementById('capacity').textContent=`${weight().toFixed(1)} / 12 kg`;}
function renderLog(){ui.log.innerHTML=state.logs.slice(0,5).map(x=>`<div class="log-entry">${escapeHtml(x)}</div>`).join('');}
function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function interact(){if(state.paused)return;const p=state.player,s=state.scene;
 if(s==='house'&&!state.flags.tv&&p.x<300){state.flags.tv=true;addLog('La televisión confirma: las defensas del río han cedido. Evacúen hacia terreno elevado.');toast('ALERTA DE EMERGENCIA: la inundación avanza.');return}
 if(s==='house'&&!state.flags.firstSupplies&&p.x>360&&p.x<750){state.flags.firstSupplies=true;addItem('battery','Pilas','▥',2,.15,'material');addItem('rope','Cuerda','〰',1,.7,'tool');addItem('medkit','Botiquín','✚',1,.6,'heal');addLog('Registraste el armario del pasillo: encontraste pilas, cuerda y un botiquín.');toast('Suministros encontrados');return}
 if(s==='house'&&p.x>1300){if(weight()>11.5){toast('Demasiado peso para cruzar con seguridad.');return}changeScene('street',90,370);state.flags.highGround=true;addLog('Saliste de la casa. El agua ya cubre la calle.');toast('Has llegado al barrio inundado. Busca una ruta elevada.');return}
 if(s==='street'&&p.x>800&&!state.flags.storeSearched){state.flags.storeSearched=true;addLog('El minimercado tiene la persiana medio abierta. Hay movimiento en el interior.');toast('Nueva zona descubierta: minimercado');state.unlocked.push('store');return}
 if(s==='street'&&p.x>1120&&!state.flags.streetCache){state.flags.streetCache=true;addItem('water','Agua limpia','▣',1,.8,'drink');addItem('food','Conserva','◉',1,.5,'food');addLog('Encontraste una mochila atrapada en la baranda de una escalera. Dentro había agua y una conserva.');toast('Mochila recuperada: agua y comida.');return}
 if(s==='street'&&p.x>1550){changeScene('roof',100,320);addLog('Alcanzaste una azotea conectada a un refugio improvisado.');toast('Refugio elevado descubierto');return}
 if(s==='roof'){if(!state.flags.survivorMet){meetSurvivor();return}if(!state.flags.refugeBuilt){openRefuge();return}addLog('El refugio sigue en pie. Puedes descansar o continuar explorando.');toast('Refugio: lugar para recuperar fuerzas.');return}
 if(s==='store'){if(!state.flags.storeSearched){state.flags.storeSearched=true;addItem('food','Conserva','◉',2,.5,'food');addItem('water','Agua limpia','▣',1,.8,'drink');addItem('wood','Madera','▤',2,1.2,'material');addLog('Encontraste conservas, una botella y tablones secos en una estantería alta.');toast('Recursos añadidos a la mochila.');return}if(p.x>950){changeScene('clinic',80,370);addLog('Una señal de emergencia te guía hasta una pequeña clínica.');return}if(p.x>700&&!state.flags.apartmentLoot){changeScene('apartment',80,350);addLog('Subiste por una escalera de servicio hasta un edificio residencial.');return}}
 if(s==='clinic'){if(state.flags.clinicNote&&p.x>820&&!state.flags.waterworksLoot){changeScene('waterworks',80,370);addLog('Seguiste una tubería marcada como DESAGÜE DE EMERGENCIA hasta la estación de bombeo.');return}if(!state.flags.clinicLoot){state.flags.clinicLoot=true;addItem('medkit','Botiquín','✚',2,.6,'heal');addItem('bandage','Vendas','✚',4,.2,'heal');addItem('antiseptic','Antiséptico','✚',1,.3,'heal');addLog('Registraste los armarios: encontraste botiquines, vendas y antiséptico.');toast('Material médico recuperado.');return}if(!state.flags.clinicNote){state.flags.clinicNote=true;addLog('Una nota advierte que el agua de la zona puede estar contaminada.');toast('Pista registrada en el diario.');return}if(p.x>1120){changeScene('street',1450,370);addLog('Saliste por la puerta trasera hacia una calle elevada.');return}}
 if(s==='apartment'){if(!state.flags.apartmentLoot){state.flags.apartmentLoot=true;addItem('battery','Pilas','▥',3,.15,'material');addItem('rope','Cuerda','〰',1,.7,'tool');addItem('food','Galletas','◉',2,.25,'food');addItem('radio','Radio portátil','▰',1,.8,'tool');addLog('Encontraste pilas, cuerda, galletas y una radio portátil.');toast('Suministros recuperados.');return}if(!state.flags.radioFixed){showModal('<h2>RADIO DE EMERGENCIA</h2><p>La radio necesita una pila para captar emisiones locales.</p><div class="modal-actions"><button id="fixRadio">INSTALAR PILA</button></div>');document.getElementById('fixRadio').onclick=()=>{if(!consume('battery')){toast('No tienes pilas.');return}state.flags.radioFixed=true;addLog('La radio capta una transmisión: el puente del este está bloqueado; la ruta segura pasa por las azoteas.');closeModal();toast('Radio reparada: pista nueva.');};return}if(p.x>1200){changeScene('roof',150,320);addLog('Una pasarela entre edificios te devuelve a la zona elevada.');return}}
 if(s==='waterworks'){if(!state.flags.waterworksLoot){state.flags.waterworksLoot=true;addItem('charcoal','Carbón filtrante','▪',2,.25,'material');addItem('metal','Chatarra metálica','▦',2,.8,'material');addItem('water','Agua limpia','▣',1,.8,'drink');addLog('Encontraste carbón filtrante, chatarra y un bidón sellado en la sala de mantenimiento.');toast('Materiales de mantenimiento recuperados.');return}if(!state.flags.valveClosed){showModal('<h2>VÁLVULA DE EMERGENCIA</h2><p>La bomba auxiliar sigue empujando agua hacia el túnel. Puedes cerrar la válvula manualmente, pero necesitas una herramienta resistente.</p><div class="modal-actions"><button id="closeValve">CERRAR VÁLVULA · USAR CUCHILLO</button></div>');document.getElementById('closeValve').onclick=()=>{if(!item('knife')){toast('Necesitas el cuchillo para liberar el mecanismo atascado.');return}state.flags.valveClosed=true;state.water=Math.max(.04,state.water-.08);state.player.stamina=Math.max(0,state.player.stamina-12);addLog('Cerraste la válvula. El flujo hacia el túnel disminuyó temporalmente.');closeModal();toast('Válvula cerrada: ruta menos peligrosa.');updateMissions();};return}if(p.x>1200){changeScene('street',1480,370);addLog('Encontraste una salida de mantenimiento hacia la calle elevada.');return}}
 toast('No hay nada útil al alcance. Explora un poco más.');
}
function changeScene(name,x,y){state.scene=name;state.player.x=x;state.player.y=y;state.player.vx=state.player.vy=0;state.player.onGround=true;state.unlocked.push(name);document.getElementById('locationName').textContent=scenes[name].name;document.getElementById('objective').textContent=scenes[name].objective;addLog('Zona: '+scenes[name].name.toLowerCase()+'.');}
function useSelected(){const it=state.inventory[state.selected];if(!it){toast('Selecciona un objeto primero.');return}
 if(it.type==='drink'){if(consume(it.id)){state.player.thirst=Math.max(0,state.player.thirst-38);addLog('Bebiste agua limpia. La sed disminuyó.');toast('Sed aliviada.');}}
 else if(it.type==='food'){if(consume(it.id)){state.player.hunger=Math.max(0,state.player.hunger-32);state.player.stamina=Math.min(100,state.player.stamina+10);addLog('Comiste una conserva. Recuperaste energía.');toast('Hambre reducida.');}}
 else if(it.type==='heal'){if(state.player.health>=100){toast('No necesitas curarte ahora.');return}if(consume(it.id)){state.player.health=Math.min(100,state.player.health+28);addLog('Usaste suministros médicos. Salud recuperada.');toast('Heridas tratadas.');}}
 else if(it.id==='jacket'){state.player.temp=Math.min(37,state.player.temp+.4);addLog('Te pusiste el abrigo. La pérdida de calor disminuye.');toast('Abrigo equipado.');}
 else if(it.id==='flashlight'){toast('Linterna lista. Útil en interiores oscuros.');}
 else if(it.id==='knife'){toast('Cuchillo equipado. Puede cortar materiales ligeros.');}
 else if(it.id==='wood'){toast('La madera sirve para reforzar un refugio o improvisar una pasarela.');}
 else if(it.id==='rope'){toast('La cuerda puede asegurar cruces y descensos adecuados.');}
 else {toast('Este objeto no se puede usar aquí.');}
 updateStats();renderInventory();}
function dropSelected(){const it=state.inventory[state.selected];if(!it){toast('No hay objeto seleccionado.');return}if(it.id==='water'||it.id==='food'||it.id==='bandage'){toast('No desperdicies un suministro esencial.');return}const name=it.name;consume(it.id);addLog('Dejaste en el suelo: '+name+'.');toast(name+' soltado.');}
function openRefuge(){showModal(`<h2>REFUGIO IMPROVISADO</h2><p>La azotea ofrece protección temporal. Puedes reforzar una entrada con madera y crear un punto de descanso.</p><p><strong>Reforzar refugio:</strong> requiere 2 unidades de madera. Reduce el riesgo de perder suministros en un evento ambiental futuro.</p><div class="modal-actions"><button id="buildRefuge">REFORZAR · 2 MADERAS</button><button id="restBtn">DESCANSAR</button></div>`);document.getElementById('buildRefuge').onclick=()=>{let wood=item('wood');if(!wood||wood.count<2){toast('Necesitas 2 unidades de madera.');return}consume('wood',2);state.flags.refugeBuilt=true;state.player.health=Math.min(100,state.player.health+5);addLog('Reforzaste la entrada del refugio con madera.');closeModal();toast('Refugio reforzado.');};document.getElementById('restBtn').onclick=()=>{state.player.stamina=100;state.player.thirst=Math.min(100,state.player.thirst+5);state.player.hunger=Math.min(100,state.player.hunger+4);state.player.temp=36.7;addLog('Descansaste en la azotea. Recuperaste resistencia.');updateStats();closeModal();toast('Has descansado.');};}
function showModal(html){document.getElementById('modalContent').innerHTML=html;document.getElementById('modal').classList.remove('hidden');}
function closeModal(){document.getElementById('modal').classList.add('hidden');}
function openCraft(){showModal(`<h2>FABRICACIÓN</h2><p>Usa materiales reales de tu inventario. Las recetas disponibles son básicas en esta primera entrega, pero sus resultados persisten en la partida.</p><div class="recipe"><div><strong>Vendaje improvisado</strong><small>Requiere: 1 material textil (simulado con suministros médicos)</small></div><button id="craftBandage">FABRICAR</button></div><div class="recipe"><div><strong>Kit de refugio</strong><small>Requiere: 2 maderas · permite reforzar una azotea</small></div><button id="craftKit">VER REFUGIO</button></div><div class="recipe"><div><strong>Filtro improvisado</strong><small>Requiere: 1 carbón filtrante + 1 cuerda · produce agua segura</small></div><button id="craftFilter">FABRICAR</button></div>`);document.getElementById('craftBandage').onclick=()=>{if(!item('medkit')){toast('Necesitas suministros médicos para improvisar un vendaje.');return}consume('medkit');addItem('bandage','Vendas','✚',2,.2,'heal');addLog('Preparaste vendas a partir del botiquín.');closeModal();toast('Vendas fabricadas.');};document.getElementById('craftKit').onclick=()=>{closeModal();if(state.scene!=='roof'){toast('Debes estar en un refugio para construir.');return}openRefuge();};document.getElementById('craftFilter').onclick=()=>{if(!item('charcoal')||!item('rope')){toast('Necesitas carbón filtrante y cuerda. Busca materiales en la estación de bombeo.');return}consume('charcoal');consume('rope');addItem('water','Agua limpia','▣',2,.8,'drink');state.flags.filterCrafted=true;addLog('Fabricaste un filtro de emergencia con carbón y cuerda. El filtro no elimina todos los contaminantes químicos.');closeModal();toast('Filtro fabricado: 2 unidades de agua segura.');updateMissions();};}
function openMap(){let names=[['house','Casa inicial','Explorada'],['street','Barrio inundado',state.unlocked.includes('street')?'Descubierta':'Sin descubrir'],['roof','Refugio elevado',state.unlocked.includes('roof')?'Descubierto':'Sin descubrir'],['store','Minimercado',state.unlocked.includes('store')?'Descubierto':'Sin descubrir'],['clinic','Clínica',state.unlocked.includes('clinic')?'Descubierta':'Sin descubrir'],['apartment','Edificio residencial',state.unlocked.includes('apartment')?'Descubierto':'Sin descubrir'],['waterworks','Estación de bombeo',state.unlocked.includes('waterworks')?'Descubierta':'Sin descubrir']];showModal(`<h2>MAPA DE ZONA</h2><p>Las conexiones conocidas dependen de las rutas descubiertas. El nivel del agua puede cambiar la accesibilidad.</p><div class="map-grid">${names.map(([id,n,sub])=>`<div class="map-tile ${state.scene===id?'active':''} ${state.unlocked.includes(id)?'':'locked'}">${n}<small>${sub}</small></div>`).join('')}</div><p>Agua: ${(state.water*100).toFixed(0)}% de la escala local · Día ${state.day}</p>`);}
function openJournal(){showModal(`<h2>REGISTRO DE SUPERVIVENCIA</h2><p>Los hechos que has descubierto se conservan en esta partida.</p><ul>${state.logs.slice().reverse().map(x=>`<li>${escapeHtml(x)}</li>`).join('')}</ul>`);}
function saveGame(){const save={...state,paused:false,near:null};try{localStorage.setItem('floodbound_save_v1',JSON.stringify(save));document.getElementById('saveStatus').textContent='Guardado · '+new Date().toLocaleTimeString();toast('Partida guardada en este navegador.');}catch(e){toast('No se pudo guardar. Comprueba el almacenamiento del navegador.');}}
function loadGame(){try{const raw=localStorage.getItem('floodbound_save_v1');if(!raw)return false;const s=JSON.parse(raw);Object.assign(state,s);renderInventory();renderLog();changeScene(state.scene,state.player.x,state.player.y);updateStats();return true}catch(e){return false}}

function updateMissions(){const f=state.flags;const missions=[['Confirmar alerta de emergencia',!!f.tv],['Registrar el armario',!!f.firstSupplies],['Salir de la vivienda',!!f.highGround],['Alcanzar un refugio elevado',state.unlocked.includes('roof')],['Registrar la clínica',!!f.clinicLoot],['Recuperar la radio',!!f.radioFixed],['Explorar la estación de bombeo',!!f.waterworksLoot],['Cerrar la válvula de emergencia',!!f.valveClosed],['Fabricar un filtro de agua',!!f.filterCrafted]];const el=document.getElementById('missionList');if(el)el.innerHTML=missions.map(([t,d])=>`<div class="${d?'done':''}">${d?'✓':'□'} ${t}</div>`).join('');const c=document.getElementById('missionCount');if(c)c.textContent=missions.filter(x=>x[1]).length+'/'+missions.length;}
function meetSurvivor(){if(state.flags.survivorMet){toast('Mara está ocupada asegurando el refugio.');return}showModal(`<h2>UNA VOZ EN LA LLUVIA</h2><p>Una superviviente llamada Mara te observa desde el otro extremo de la azotea. Tiene las manos temblorosas y una mochila casi vacía.</p><p><em>—Vi gente atrapada cerca del minimercado. Si encuentras agua limpia, puedo compartirte una ruta por los tejados.</em></p><div class="modal-actions"><button id="helpMara">COMPARTIR AGUA</button><button id="askMara">PREGUNTAR POR LA RUTA</button></div>`);document.getElementById('helpMara').onclick=()=>{if(!consume('water')){toast('No tienes agua limpia para compartir.');return}state.flags.survivorMet=true;addItem('battery','Pilas','▥',2,.15,'material');addLog('Compartiste agua con Mara. Te dio dos pilas y señaló una ruta entre azoteas.');closeModal();toast('Confianza con Mara aumentó.');updateMissions()};document.getElementById('askMara').onclick=()=>{state.flags.survivorMet=true;addLog('Mara señaló una pasarela hacia el minimercado. Te pidió que no desperdicies el agua potable.');closeModal();toast('Ruta alternativa registrada en el diario.')}}
function updateStats(){updateMissions();const p=state.player;document.getElementById('healthText').textContent=Math.round(p.health);document.getElementById('healthBar').style.width=p.health+'%';document.getElementById('hungerText').textContent=Math.round(p.hunger)+'%';document.getElementById('hungerBar').style.width=p.hunger+'%';document.getElementById('thirstText').textContent=Math.round(p.thirst)+'%';document.getElementById('thirstBar').style.width=p.thirst+'%';document.getElementById('tempText').textContent=p.temp.toFixed(1)+'°';document.getElementById('tempBar').style.width=Math.max(0,Math.min(100,(p.temp-34)*25))+'%';document.getElementById('condition').textContent=p.temp<35.5?'Frío peligroso':p.health<45?'Herido · debilitado':'Empapado · alerta';}
function rect(x,y,w,h,c){ctx.fillStyle=c;ctx.fillRect(Math.round(x),Math.round(y),Math.round(w),Math.round(h));}
function line(x1,y1,x2,y2,c,w=1){ctx.strokeStyle=c;ctx.lineWidth=w;ctx.beginPath();ctx.moveTo(x1,y1);ctx.lineTo(x2,y2);ctx.stroke();}
function drawBackground(cam){const s=scenes[state.scene];rect(0,0,W,H,s.sky);
 // layered storm sky
 for(let i=0;i<8;i++){const y=38+i*23;rect((i*131-cam*.12)%1100-60,y,180+(i%3)*80,8,'#2b3b43');rect((i*173-cam*.1)%1000,y+8,120,4,'#24343c')}
 // distant skyline
 for(let i=0;i<12;i++){let x=((i*126-cam*.25)%1300+1300)%1300-100;let h=90+(i*37%110);rect(x,300-h,70,h,'#17252d');rect(x+9,310-h,12,7,'#65747a');rect(x+34,330-h,10,7,'#5e7076');}
 // rain
 ctx.strokeStyle='#91b2ba44';ctx.lineWidth=1;for(let i=0;i<90;i++){let x=(i*47+state.time*3)%W,y=(i*31+state.time*7)%H;ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x-5,y+12);ctx.stroke();}
}
function drawHouse(cam){rect(0,300,W,240,'#252e31');rect(0,425,W,115,'#353b39');rect(0,425,W,7,'#59605b');
 // interior wall and floor
 rect(0,80,Math.min(760,W),350,'#374044');rect(0,80,760,9,'#667176');rect(0,80,8,350,'#758087');
 // wallpaper panels
 for(let x=15;x<760;x+=80){rect(x,95,2,320,'#444e51');rect(x+5,95,1,320,'#30393d')}
 // window rain
 rect(72,140,165,125,'#111e25');rect(80,148,149,109,'#3b5963');line(154,148,154,257,'#111c22',7);line(80,200,229,200,'#111c22',7);
 // television
 rect(290,282,126,83,'#171c1f');rect(298,290,110,63,'#627a7d');rect(306,298,94,48,'#24343a');rect(310,307,82,4,'#d4b486');rect(310,318,67,3,'#9fb5b5');rect(310,328,77,3,'#9fb5b5');rect(345,365,17,13,'#171c1f');rect(326,378,54,5,'#171c1f');
 // kitchen counter
 rect(500,325,200,24,'#6c6253');rect(510,349,13,77,'#514a41');rect(679,349,13,77,'#514a41');rect(533,292,35,32,'#a7aaa1');rect(575,303,23,21,'#d2c9b5');rect(620,294,28,30,'#606e70');
 // door exit
 rect(760,178,95,248,'#493c32');rect(770,190,75,236,'#604b3b');rect(830,300,6,6,'#d4ad6c');
 // cabinet supplies
 rect(440,250,48,176,'#594d40');rect(434,245,60,10,'#7d6c55');rect(446,268,36,5,'#c6b38d');rect(446,302,36,5,'#c6b38d');rect(446,336,36,5,'#c6b38d');
 // water at threshold
 let wl=475-state.water*210;rect(0,wl,W,H-wl,'#245363b8');for(let i=0;i<20;i++)line((i*57+state.time*1.8)%W,wl+8+(i%4)*12,(i*57+state.time*1.8)%W+22,wl+8+(i%4)*12,'#8bbac24d',2);
}
function drawStreet(cam){rect(0,0,W,425,'#1a2930'); // street floor and flooded road
 rect(0,380,W,160,'#353d3b');rect(0,420,W,120,'#254a57');const wl=420-state.water*120;rect(0,wl,W,H-wl,'#245567c9');
 // row houses
 for(let i=0;i<8;i++){let x=i*180-cam*.7+30;rect(x,145,135,245,'#424543');rect(x-6,135,147,18,'#6c716b');rect(x+14,172,35,49,'#19262d');rect(x+72,172,38,49,'#17242b');rect(x+20,246,94,135,'#5b5144');rect(x+28,260,78,121,'#3c3731');rect(x+15,231,103,9,'#a18a6b');}
 // car
 let cx=500-cam*.4;rect(cx,355,118,38,'#58656a');rect(cx+14,335,69,25,'#62757b');rect(cx+17,339,25,17,'#293b43');rect(cx+48,339,29,17,'#293b43');rect(cx+15,386,23,15,'#11181b');rect(cx+83,386,23,15,'#11181b');
 // floating debris
 for(let i=0;i<12;i++){let x=(i*97+state.time*1.4-cam*.8)%1100;rect(x,wl+15+(i%4)*21,18,5,'#7a8a83')}
 // route to roof
 rect(820-cam*.7,255,115,10,'#8a8b7e');rect(900-cam*.7,255,12,125,'#6d726c');rect(910-cam*.7,255,45,10,'#8a8b7e');
}
function drawRoof(cam){rect(0,0,W,H,'#263b43');for(let i=0;i<6;i++){let x=i*180-cam*.4;rect(x,100,120,240,'#1c2a31');rect(x+15,130,26,36,'#657980');rect(x+65,130,26,36,'#657980');}
 rect(0,360,W,180,'#4b4d47');for(let x=0;x<W;x+=35){rect(x,360,3,180,'#373e3c');}
 rect(40,330,880,18,'#777c70');rect(60,300,160,30,'#6c7167');rect(90,275,60,25,'#7b8379');
 // shelter tent
 rect(560,265,170,80,'#5a4f3f');rect(580,245,130,20,'#8a7254');rect(580,265,130,65,'#343d3d');rect(605,280,80,50,'#171f22');
 // water far below
 rect(0,420,W,120,'#204c5a');for(let i=0;i<20;i++)line(i*55,438+(i%3)*22,i*55+24,438+(i%3)*22,'#8bbac244',2);
}
function drawStore(cam){rect(0,0,W,H,'#17252c');rect(0,430,W,110,'#244b58');rect(0,0,W,430,'#353c3b');rect(0,75,W,10,'#7b8178');for(let x=40;x<900;x+=190){rect(x,150,130,245,'#615d50');rect(x+8,170,114,10,'#93866d');rect(x+8,230,114,10,'#93866d');rect(x+8,290,114,10,'#93866d');for(let j=0;j<5;j++){rect(x+12+j*21,183,13,37,['#a87856','#6d9890','#bdab7e'][j%3]);rect(x+12+j*21,244,13,39,['#8e6551','#657c85','#c0b18b'][j%3]);}}rect(0,420,W,120,'#265363c9');}
function drawClinic(cam){rect(0,0,W,H,'#202e35');rect(0,0,W,430,'#b8b7aa');for(let x=30;x<W;x+=180){rect(x,60,110,150,'#34464d');rect(x+8,68,94,134,'#9bb0ad');line(x+55,68,x+55,202,'#42555a',4);rect(x-10,222,130,9,'#6e7775');rect(x,235,110,150,'#dad6c9');rect(x+8,246,94,5,'#8d9996');rect(x+8,270,94,5,'#8d9996');rect(x+8,294,94,5,'#8d9996');}rect(0,420,W,120,'#2a5662');rect(70,340,120,70,'#d2d0c4');rect(80,350,100,10,'#f0eee4');rect(80,370,100,30,'#a8b6b4');rect(650,130,170,12,'#c7c8bd');rect(660,142,150,75,'#53676d');rect(685,160,100,35,'#9db8b8');rect(0,420,W,120,'#2b5b69cc');}
function drawApartment(cam){rect(0,0,W,H,'#252f35');rect(0,0,W,410,'#424743');for(let i=0;i<5;i++){let x=i*190-cam*.35;rect(x+15,60,135,330,'#353d3b');rect(x+28,85,45,75,'#19272e');rect(x+86,85,45,75,'#19272e');rect(x+28,185,103,8,'#9a8e79');rect(x+28,205,103,70,'#5c5c50');rect(x+36,216,87,45,'#333c3d');rect(x+28,295,103,8,'#9a8e79');}rect(0,410,W,130,'#28515d');rect(250,340,100,65,'#6b6b5d');rect(260,350,80,10,'#a3a18d');rect(650,300,100,100,'#343e40');rect(665,315,70,70,'#9c9b89');}
function drawWaterworks(cam){rect(0,0,W,H,'#17272d');rect(0,0,W,425,'#343e3e');for(let x=30;x<1000;x+=220){rect(x-cam*.28,55,150,320,'#252f32');rect(x+18-cam*.28,80,112,12,'#687875');rect(x+18-cam*.28,120,112,12,'#687875');rect(x+18-cam*.28,160,112,12,'#687875');line(x+30-cam*.28,180,x+30-cam*.28,330,'#a27b54',5);line(x+75-cam*.28,180,x+75-cam*.28,330,'#a27b54',5);line(x+120-cam*.28,180,x+120-cam*.28,330,'#a27b54',5)}rect(620-cam*.3,270,180,130,'#4b5550');rect(650-cam*.3,290,120,75,'#18262b');rect(690-cam*.3,300,40,55,'#9b9b84');rect(0,425,W,115,'#244d59');let wl=450-state.water*115;rect(0,wl,W,H-wl,'#245567c9');for(let x=0;x<W;x+=80){line(x,wl+12,x+35,wl+12,'#6a9ca4',2)}}
function drawPlayer(x,y){ctx.save();ctx.translate(Math.round(x),Math.round(y));ctx.scale(state.player.face,1);
 // shadow
 rect(-12,2,27,4,'#0b1419aa');
 // legs + boots
 rect(-8,-22,7,22,'#263038');rect(2,-22,7,22,'#2c363b');rect(-10,-3,10,5,'#171d21');rect(1,-3,12,5,'#171d21');
 // coat body silhouette
 rect(-10,-48,22,28,'#59655e');rect(-12,-46,5,22,'#394b4a');rect(8,-45,6,21,'#394b4a');rect(-9,-48,20,4,'#9a8b70');rect(-5,-40,12,3,'#c0a77d');
 // arms
 rect(-14,-45,5,19,'#5d6a63');rect(12,-43,5,18,'#5d6a63');rect(-15,-27,6,5,'#b48c70');rect(12,-27,6,5,'#b48c70');
 // head, hair, face
 rect(-7,-62,16,15,'#c49a7b');rect(-9,-66,18,9,'#202a30');rect(-8,-70,14,7,'#1a242a');rect(4,-58,5,3,'#1b252b');
 // hood collar and backpack
 rect(-13,-48,6,20,'#8c775c');rect(-17,-45,6,18,'#3c4e51');rect(-16,-47,5,3,'#a2a18d');
 // rain highlights
 rect(-8,-47,3,15,'#879087');rect(8,-45,2,12,'#8e9789');
 ctx.restore();}
function drawWorld(){const p=state.player,cam=Math.max(0,Math.min(scenes[state.scene].width-W,p.x-W*.4));drawBackground(cam);if(state.scene==='house')drawHouse(cam);if(state.scene==='street')drawStreet(cam);if(state.scene==='roof')drawRoof(cam);if(state.scene==='store')drawStore(cam);if(state.scene==='clinic')drawClinic(cam);if(state.scene==='apartment')drawApartment(cam);if(state.scene==='waterworks')drawWaterworks(cam);
 // foreground water overlays in flooded scenes
 if(state.scene!=='roof'&&state.water>.18){ctx.fillStyle='#2b718244';ctx.fillRect(0,Math.max(390,420-state.water*90),W,150);for(let i=0;i<25;i++)line((i*49+state.time*2)%W,430+(i%5)*17,(i*49+state.time*2)%W+19,430+(i%5)*17,'#a4d2d044',1)}
 // objects and contextual markers
 if(state.scene==='house'){if(!state.flags.tv){rect(330-cam,272,8,8,'#d6ae76');}if(!state.flags.firstSupplies){rect(464-cam,239,7,7,'#d6ae76');}}
 if(state.scene==='street'){rect(870-cam,330,15,5,'#d7ad73');rect(1560-cam,250,22,5,'#d7ad73');}
 if(state.scene==='roof'){rect(700-cam,236,10,8,'#d7ad73');}
 if(state.scene==='store'&&!state.flags.storeSearched){rect(470-cam,160,10,10,'#d7ad73');}if(state.scene==='clinic'&&!state.flags.clinicLoot){rect(470-cam,160,12,12,'#d7ad73');}if(state.scene==='apartment'&&!state.flags.apartmentLoot){rect(470-cam,160,12,12,'#d7ad73');}
 drawPlayer(p.x-cam,p.y);
 // vignetting
 const g=ctx.createRadialGradient(W/2,H/2,100,W/2,H/2,600);g.addColorStop(0,'#00000000');g.addColorStop(1,'#05090b99');ctx.fillStyle=g;ctx.fillRect(0,0,W,H);
 // waterline visual alert
 if(state.water>.4){rect(0,0,W,3,'#b56c61');}
}
const keys={};window.addEventListener('keydown',e=>{if(['ArrowLeft','ArrowRight','ArrowUp','ArrowDown',' '].includes(e.key))e.preventDefault();keys[e.key.toLowerCase()]=true;if(e.key==='e'||e.key==='E')interact();if(e.key===' '&&!state.paused)jump();if(e.key.toLowerCase()==='i')document.querySelector('#inventory').scrollIntoView({behavior:'smooth',block:'center'});if(e.key==='Escape'){state.paused=!state.paused;if(state.paused)showModal('<h2>PAUSA</h2><p>La simulación está detenida.</p><div class="modal-actions"><button id="resumeBtn">CONTINUAR</button><button id="pauseSave">GUARDAR PARTIDA</button></div>');}});window.addEventListener('keyup',e=>keys[e.key.toLowerCase()]=false);
function jump(){if(state.player.onGround){state.player.vy=-8;state.player.onGround=false;}}
document.querySelectorAll('[data-hold]').forEach(b=>{const k=b.dataset.hold;const start=e=>{e.preventDefault();keys[k]=true};const end=e=>{e.preventDefault();keys[k]=false};b.addEventListener('pointerdown',start);['pointerup','pointercancel','pointerleave'].forEach(ev=>b.addEventListener(ev,end));});
document.querySelectorAll('[data-action]').forEach(b=>b.addEventListener('click',()=>b.dataset.action==='jump'?jump():interact()));
document.getElementById('useItem').onclick=useSelected;document.getElementById('dropItem').onclick=dropSelected;document.getElementById('interact')?.addEventListener('click',interact);
document.getElementById('searchBtn').onclick=interact;document.getElementById('craftBtn').onclick=openCraft;document.getElementById('mapBtn').onclick=openMap;document.getElementById('saveBtn').onclick=saveGame;document.getElementById('journalBtn').onclick=openJournal;document.getElementById('pauseBtn').onclick=()=>{state.paused=!state.paused;showModal(`<h2>${state.paused?'PAUSA':'CONTINUAR'}</h2><p>La simulación ${state.paused?'está detenida':'continúa'}.</p><div class="modal-actions"><button id="resumeBtn">CONTINUAR</button><button id="pauseSave">GUARDAR PARTIDA</button></div>`);};
document.getElementById('closeModal').onclick=()=>{closeModal();state.paused=false;};
document.getElementById('modal').addEventListener('click',e=>{if(e.target.id==='modal'){closeModal();state.paused=false}});
document.getElementById('modalContent').addEventListener('click',e=>{if(e.target.id==='resumeBtn'){closeModal();state.paused=false}if(e.target.id==='pauseSave')saveGame()});
function update(dt){if(state.paused)return;const p=state.player;let move=0;if(keys['a']||keys['arrowleft']||keys.left)move=-1;if(keys['d']||keys['arrowright']||keys.right)move=1;p.vx=move*2.3;if(move)p.face=move;p.x=Math.max(18,Math.min(scenes[state.scene].width-30,p.x+p.vx));if(keys['w']||keys['arrowup']||keys.up){if(p.onGround)jump()}p.vy+=.34;p.y+=p.vy;const ground=scenes[state.scene].ground;if(p.y>=ground){p.y=ground;p.vy=0;p.onGround=true}
 state.time+=dt*60;state.minute+=dt*2.2;if(state.minute>=1440){state.minute-=1440;state.day++}
 state.water=Math.min(1,state.water+dt*.0026);
 p.hunger=Math.min(100,p.hunger+dt*.19);p.thirst=Math.min(100,p.thirst+dt*.3);
 if(state.scene!=='roof'&&state.water>.22)p.temp=Math.max(33.5,p.temp-dt*.012);
 if(p.thirst>85||p.hunger>90||p.temp<34.7)p.health=Math.max(0,p.health-dt*.4);
 if(p.health<=0){toast('Has colapsado. Recarga tu último guardado o inicia una nueva partida.');state.paused=true;}
 state.autosave+=dt;if(state.autosave>45){state.autosave=0;try{localStorage.setItem('floodbound_save_v1',JSON.stringify({...state,paused:false,near:null}))}catch(e){}}
 const mins=Math.floor(state.minute),hh=String(Math.floor(mins/60)).padStart(2,'0'),mm=String(mins%60).padStart(2,'0');document.getElementById('clock').textContent=`DÍA ${state.day} · ${hh}:${mm}`;document.getElementById('weather').textContent=state.water>.6?'INUNDACIÓN CRÍTICA':state.water>.25?'AGUA EN ASCENSO':'LLUVIA INTENSA';updateStats();
 ui.hint.classList.toggle('show',Math.abs(p.x-(state.scene==='house'?330:state.scene==='street'?870:state.scene==='roof'?700:470))<120);
}
let last=performance.now();function frame(now){const dt=Math.min(.05,(now-last)/1000);last=now;update(dt);drawWorld();requestAnimationFrame(frame)}
// Intro screen controls
const intro=document.getElementById('intro-screen');document.getElementById('startGame').onclick=()=>{intro.classList.add('hidden');addLog('La evacuación ha comenzado. Revisa la televisión y registra el armario antes de salir.');};document.getElementById('continueGame').onclick=()=>{if(loadGame()){intro.classList.add('hidden');toast('Partida recuperada.');}else{intro.classList.add('hidden');toast('No hay partida guardada; comienza una nueva evacuación.');}};
// Initial story
addLog('La televisión está encendida. Una alerta interrumpe la programación.');
addLog('Busca suministros, pero no pierdas demasiado tiempo: el agua está subiendo.');
renderInventory();updateStats();
if(localStorage.getItem('floodbound_save_v1')){const banner=document.createElement('div');banner.className='resume-banner';banner.textContent='Hay una partida guardada. Pulsa “Continuar” para recuperarla.';document.getElementById('saveStatus').textContent='Guardado disponible';}
requestAnimationFrame(frame);
window.FLOODBOUND={state,saveGame,loadGame,changeScene};
})();