# FLOODBOUND — hoja de ruta

- V1.4: estación de bombeo, válvula de emergencia, filtro de agua y objetivos adicionales.
- V1.5: misiones secundarias con estados, rescate de NPC y sistema de confianza persistente.
- V1.6: heridas, infecciones, descanso avanzado y refugios con mejoras reales.
- V1.7: expansión de barrio, rutas verticales y nuevos puntos de interés.
- V2.0: animaciones originales, audio ambiental y revisión de rendimiento móvil.

El objetivo de 100 horas requiere volumen de contenido y rejugabilidad demostrables; no se declara alcanzado por adelantado.
