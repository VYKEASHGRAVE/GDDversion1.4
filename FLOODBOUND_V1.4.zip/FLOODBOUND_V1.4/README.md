# FLOODBOUND V1.4 — supervivencia sistémica y estación de bombeo

## Ejecutar
Descomprime el ZIP y abre `index.html` en un navegador moderno. Para guardado fiable, ejecuta `python -m http.server 8000` en esta carpeta y abre `http://localhost:8000`. No requiere dependencias.

## Novedades V1.4
- Nueva zona: estación de bombeo conectada a la clínica tras descubrir la nota de contaminación.
- Botín nuevo: carbón filtrante y chatarra metálica.
- Evento interactivo de válvula de emergencia: requiere cuchillo y reduce temporalmente el nivel de agua simulado.
- Receta de filtro improvisado: carbón filtrante + cuerda para fabricar dos unidades de agua limpia. El registro aclara que el filtro no elimina todos los contaminantes químicos.
- Mapa ampliado a siete zonas y tres objetivos nuevos: explorar estación, cerrar válvula y fabricar filtro.
- Se conservan inventario, necesidades, inundación progresiva, refugio, radio y guardado local.

## Controles
A/D o flechas: moverse. W/flecha arriba/espacio: saltar. E: interactuar. En móvil, usa los controles táctiles.

## Alcance honesto
Esta versión amplía el prototipo con una zona y sistemas nuevos, pero todavía no es un juego de 100 horas. Esa meta requiere muchas más regiones, misiones, simulación, contenido audiovisual original y pruebas sostenidas. El ZIP no se infla con datos vacíos.
